In de terminal run eerst 
`java -jar Controller.jar'

Daarna kunnen de andere .jar files gerund worden, waarbij je altijd het ip adres van de pc waarop Controller.jar draait als server ip aanhoudt.
Na leader election wordt het ip adres van de nieuwe leader geprint.
Gebruik dit adres als server ip adres bij het toevoegen van nieuwe devices.
